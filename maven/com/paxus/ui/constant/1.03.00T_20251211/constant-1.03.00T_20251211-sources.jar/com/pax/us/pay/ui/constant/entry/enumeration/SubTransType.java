package com.pax.us.pay.ui.constant.entry.enumeration;

/**
 * Sub Trans. Type
 * Used in {@link com.pax.us.pay.ui.constant.entry.OptionEntry#ACTION_SELECT_SUB_TRANS_TYPE}
 */
public final class SubTransType {
    private SubTransType(){

    }

    /**
     * By CardNum
     */
    public static final String BY_CARDNUM = "BY CARDNUM";

    /**
     * By Ref. No.
     */
    public static final String BY_REFNO = "BY REFNO.";

    /**
     * By Global UID
     */
    public static final String BY_GLOBAL_UID = "BY GLOBAL UID";

    /**
     * By Trans Number
     */
    public static final String BY_TRANS_NUMBER = "BY TRANS NUMBER";
}
