package com.pax.us.pay.ui.constant.entry.enumeration;

/**
 * Input Type
 */
public final class InputType {
    private InputType(){

    }
    /**
     * TEXT
     */
    public static final String ALLTEXT = "ALLTEXT";
    /**
     * TEXT
     */
    public static final String PASSWORD = "PASSWORD";
    /**
     * TEXT
     */
    public static final String NUM = "NUM";
    /**
     * TEXT
     */
    public static final String PASSCODE = "PASSCODE";



}
