package com.pax.us.pay.ui.constant.entry.enumeration;

/**
 * Transaction Status
 */
public enum TransactionStatus {
    DECLINED,
    APPROVED,
    PARTIALLY_APPROVED;
}
